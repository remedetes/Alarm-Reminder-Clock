package com.example.dtsoa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class HalamanAwal extends AppCompatActivity implements View.OnClickListener {

    ImageView img_ras;
    Button btn_jelajah, btn_about;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_halaman_awal);

//        img_ras = findViewById(R.id.gambar);
        btn_about = findViewById(R.id.btn_about);
        btn_jelajah = findViewById(R.id.btn_jelajah);

        btn_jelajah.setOnClickListener(this);
        btn_about.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_about:
                Intent intent = new Intent(HalamanAwal.this, HalamanAbout.class);
                startActivity(intent);
                break;
            case R.id.btn_jelajah:
                Intent pindah = new Intent(HalamanAwal.this, MainActivity.class);
                startActivity(pindah);
                break;
        }
    }

    }

